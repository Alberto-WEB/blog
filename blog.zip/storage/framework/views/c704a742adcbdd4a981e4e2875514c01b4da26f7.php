

<?php $__env->startSection('title', 'Siur'); ?>
<link rel="shortcut icon" href="<?php echo e(asset('images/logo_white.png')); ?>" type="image/png">

<?php $__env->startSection('content_header'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('images/fondo_web.png')); ?>" class="img-fluid" alt="Admin Blog Siur" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/index.blade.php ENDPATH**/ ?>