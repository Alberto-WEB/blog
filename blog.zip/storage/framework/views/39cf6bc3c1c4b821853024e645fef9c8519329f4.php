

<?php $__env->startSection('title', 'Siur | Publicaciones'); ?>
<link rel="shortcut icon" href="<?php echo e(asset('images/logo_white.png')); ?>" type="image/png">


<?php $__env->startSection('content_header'); ?>

    <a class="btn btn-secondary btn-sm float-right" href="<?php echo e(route('admin.posts.create')); ?>">Nuevo post</a>

    <h1>Listado de posts</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  
    <?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('info')); ?></strong>
    </div>
    <?php endif; ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.posts-index')->html();
} elseif ($_instance->childHasBeenRendered('cpFUV2G')) {
    $componentId = $_instance->getRenderedChildComponentId('cpFUV2G');
    $componentTag = $_instance->getRenderedChildComponentTagName('cpFUV2G');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cpFUV2G');
} else {
    $response = \Livewire\Livewire::mount('admin.posts-index');
    $html = $response->html();
    $_instance->logRenderedChild('cpFUV2G', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>