<a href="/">
    
    <img class="block lg:hidden w-auto" src="<?php echo e(asset('images/logo_color_responsive.png')); ?>" alt="Siur">
    <img class="hidden lg:block w-auto" src="<?php echo e(asset('images/logo_color_web.png')); ?>" alt="Siur">
</a>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>