@extends('adminlte::page')

@section('title', 'Siur')
<link rel="shortcut icon" href="{{ asset('images/logo_white.png') }}" type="image/png">

@section('content_header')

@stop

@section('content')
    <img src="{{ asset('images/fondo_web.png') }}" class="img-fluid" alt="Admin Blog Siur" />
@stop
